package com.cts.HomeInsurance.servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.openqa.selenium.remote.http.HttpRequest;
import com.cts.HomeInsurance.BO.HomeownerBO;
import com.cts.HomeInsurance.BO.LocationBO;
import com.cts.HomeInsurance.BO.PolicyBO;
import com.cts.HomeInsurance.BO.PropertyBO;
import com.cts.HomeInsurance.BO.QuoteBo;
import com.cts.HomeInsurance.BO.UserBO;
import com.cts.HomeInsurance.DAO.LocationDAO;
import com.cts.HomeInsurance.DAO.QuoteDAO;
import com.cts.HomeInsurance.DAO.UserDAO;
import com.cts.HomeInsurance.model.Homeowner;
import com.cts.HomeInsurance.model.Location;
import com.cts.HomeInsurance.model.Policy;
import com.cts.HomeInsurance.model.Property;
import com.cts.HomeInsurance.model.Quote;
import com.cts.HomeInsurance.model.User;





@WebServlet("/")
public class Homepage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<String> errorList;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String act = req.getServletPath();
		try {
			switch (act) {
			case"/retrieveQuoteSummary":
				retrieveQuoteSummary(req, res);
				break;
			case"/myPolicies":
				myPolicies(req, res);
				break;
			case"/retrieveQuote":
				retrieveQuote(req, res);
				break;
			case"/policyConf":
				policyConf(req, res);
				break;
			case"/postPolicy":
				postPolicy(req, res);
				break;
			case"/buyQuote":
				showBuyQuote(req, res);
				break;
			case"/quoteSummary":
				showQuoteSummary(req, res);
				break;
			case"/quote":
				showQuote(req,res);
				break;
			case"/postProperty":
				postProperty(req,res);
				break;
			case "/property":
				showProperty(req,res);
				break;			
			case"/postHomeowner":
				postHomeowner(req,res);
				break;
			case "/homeowner":
				showHomeowner(req, res);
				break;
			case "/postLocation":
				postLocation(req, res);
				break;
			case "/location":
				showLocation(req, res);
				break;
			case "/welcomeUser":
				showWelcome(req, res);
				break;
			case "/registerUser":
				postRegister(req, res);
				break;
			case "/showRegisterUser":
				showRegister(req, res);
				break;
			case "/userLogIn":
				postLogIn(req, res);
				break;
			case "/showUserPage":
				showLogIn(req, res);
				break;
			case "/logOutUser":
				logOut(req, res);
				break;
			default:
				showLogIn(req, res);
			}
		} catch (Exception e) {
			e.getMessage();
		}
	}

	private void retrieveQuoteSummary(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, IOException, SQLException, ServletException {
		HttpSession ses=req.getSession();
		User u=(User) ses.getAttribute("currentUser");
		
		int uid=u.getUserId();
		int quoteId =Integer.parseInt(req.getParameter("id"));
		
		QuoteBo qbo=new QuoteBo();
		Quote q=qbo.getQuoteById(quoteId);
		ses.setAttribute("currentQuote", q);
		
		LocationBO lbo=new LocationBO();
		Location l=lbo.getLocationQuote_Id(quoteId);
		ses.setAttribute("currentLocation", l);
		
		HomeownerBO hbo=new HomeownerBO();
		Homeowner h=hbo.getHomeownerByUser_Id(uid);
		ses.setAttribute("currentHomeowner", h);
		
		PropertyBO pbo=new PropertyBO();
		Property p=pbo.getPropertyByLocation_Id(l.getLocationId());
		ses.setAttribute("currentProperty", p);
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/QuoteSummary.jsp");
		rd.forward(req, res);
	}

	private void myPolicies(HttpServletRequest req, HttpServletResponse res) throws SQLException, ServletException, IOException {
		HttpSession ses=req.getSession();
		User u=(User) ses.getAttribute("currentUser");
		String name=u.getUserName();
		PolicyBO pBO = new PolicyBO();

		List<Policy> pl=pBO.getAllPolicies(u.getUserName());
		ses.setAttribute("policyList", pl);
		for(Policy p:pl) {
			System.out.println(p.getPolicyId());
		}
		ses.setAttribute("user",name);
		RequestDispatcher rd=req.getRequestDispatcher("WEB-INF/views/MyPolicies.jsp");
		rd.forward(req, res);
		
	}

	private void retrieveQuote(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, IOException, SQLException, ServletException {
		HttpSession ses = req.getSession();	
		User u=(User)ses.getAttribute("currentUser");
		String name=u.getUserName();
		QuoteBo qBO = new QuoteBo();
		
		List<Quote> ql=qBO.getAllQuotes(u.getUserId());
		for(Quote q:ql) {
			System.out.println(q.getMonthlyPremium());
		}
		ses.setAttribute("retQuote", ql);
		ses.setAttribute("user", name);
		//req.getRequestDispatcher("/WEB-INF/views/RetrieveQuote.jsp").forward(req, res);
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/RetrieveQuote.jsp");
		rd.forward(req, res);

	}

	private void policyConf(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/PolicyConf.jsp");
		rd.forward(req, res);

	}

	private void postPolicy(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException, IOException {
		HttpSession ses = req.getSession();
		Quote q= (Quote) ses.getAttribute("currentQuote");
		User u = (User) ses.getAttribute("currentUser");

		String date = req.getParameter("policyDate");
		String[] arr = date.split("-");

		java.sql.Date sdate=new java.sql.Date((Integer.valueOf(arr[0])-1900),Integer.valueOf(arr[1])-1,Integer.valueOf(arr[2]));
		LocalDate today= LocalDate.now();

		if(LocalDate.parse(date).isBefore(today.plusDays(61))&&
				LocalDate.parse(date).isAfter(today.minusDays(1)))
		{
			Policy p = new Policy(q.getQuoteId(),u.getUserId(), (sdate));

			PolicyBO pBO= new PolicyBO();
			int pId= pBO.registerPolicy(p);
			p.setPolicyId(pId);
			ses.setAttribute("currentPolicy", p);
			res.sendRedirect("policyConf");
		}
		else
		{
			errorList.add("Policy Start Date should be within 60 days of "+today);
			res.sendRedirect("postPolicy");
		}

	}

	private void showBuyQuote(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/Policy.jsp");
		rd.forward(req, res);

	}

	private void showQuoteSummary(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException, ClassNotFoundException, SQLException {

		
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/QuoteSummary.jsp");
		rd.forward(req, res);
	}

	private void showQuote(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException, ClassNotFoundException, SQLException {
		HttpSession ses=req.getSession();

		Quote quote = new Quote();
		Location location=(Location) ses.getAttribute("currentLocation");
		Property property=(Property) ses.getAttribute("currentProperty");
		quote.setLocationId(location.getLocationId());
		int RATE = 5;
		int EXPOSURE_UNITS = 1000;
		int cons = 120;
		int MEDICAL_EXPENSE = 5000;
		double totalNumberOfEU=property.getMarketValue() / EXPOSURE_UNITS;

		double yp =RATE *totalNumberOfEU ;
		double nyp=0;
		String loc= location.getResidenceType();

		if(loc.equals("Single-Family Home")) {
			nyp = (yp + (yp * 0.05 ));
		}
		else if(loc.equals("Condo") || loc.equals("Duplex") || location.equals("Apartment"))  {
			nyp = (yp + (yp * 0.06 ));
		}
		else if(loc.equals("Townhouse") || loc.equals("Rowhouse")) {
			nyp = (yp + (yp * 0.07 ));
		}

		double monthlyp=nyp/12;
		quote.setMonthlyPremium((float) monthlyp);

		//dwellingCoverage
		int realHomeValue = 0;
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		int homeValue = property.getSquareFootage() * cons;
		int yb1=Integer.parseInt(property.getYearBuilt());
		int yb=currentYear-yb1;	

		if(yb < 5 ) {
			realHomeValue = homeValue - (homeValue * 10/100);
		}
		else if(yb > 5 && yb < 10) {
			realHomeValue = homeValue - (homeValue * 20/100);
		}
		else if(yb > 10 && yb < 20) {
			realHomeValue = homeValue - (homeValue * 30/100);
		}
		else if(yb > 20) {
			realHomeValue = homeValue - (homeValue * 50/100);
		}
		double dwellingCoverage = (property.getMarketValue() * 50/100) + realHomeValue;

		quote.setDwellingCoverage((float) dwellingCoverage);
		quote.setDetatchedStructures((float) (dwellingCoverage *(0.1)));
		quote.setPersonalProperty((float) (dwellingCoverage * 6/100));
		quote.setMedicalExpenses(MEDICAL_EXPENSE);
		quote.setAddLivingExp((float) (dwellingCoverage * 20/100));
		quote.setDeductible(property.getMarketValue() * 1/100);

		QuoteDAO qdao=new QuoteDAO();
		int r=qdao.registerQuote(quote);
		quote.setQuoteId(r);
		ses.setAttribute("currentQuote",quote);
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/Quote.jsp");
		rd.forward(req, res);	
	}

	private void postProperty(HttpServletRequest req, HttpServletResponse res) throws ClassNotFoundException, SQLException, IOException{

		float v=Float.parseFloat(req.getParameter("value"));
		String y=req.getParameter("year");
		int s=Integer.parseInt(req.getParameter("size"));
		String d=req.getParameter("dwellingStyle");
		String r=req.getParameter("roofMaterial");
		String t=req.getParameter("typeOfGarage");
		int f=Integer.parseInt(req.getParameter("fullBath"));
		int h=Integer.parseInt(req.getParameter("halfBath"));
		boolean p=Boolean.parseBoolean(req.getParameter("pool"));

		HttpSession ses=req.getSession();

		Location l=(Location) ses.getAttribute("currentLocation");
		//int locId=l.getLocationId();
		//System.out.println(locId);
		int ii=l.getLocationId();
		System.out.println(ii);
		Property property=new Property(l.getLocationId(), v, y, s, d, r, t, f, h, p);
		PropertyBO pbo=new PropertyBO();
		pbo.registerProperty(property);

		ses.setAttribute("currentProperty", property);
		res.sendRedirect("quote");
	}

	private void showProperty(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/Property.jsp");
		rd.forward(req, res);

	}

	private void postHomeowner(HttpServletRequest req, HttpServletResponse res) throws ParseException, ClassNotFoundException, SQLException, IOException {
		HttpSession ses = req.getSession();
		User user = (User) ses.getAttribute("currentUser");
		int userId = user.getUserId();

		String n=req.getParameter("firstName");
		String l=req.getParameter("lastName");


		String d=req.getParameter("dob");
		//		SimpleDateFormat sdf = new SimpleDateFormat("MM-DD-YY");
		//		java.util.Date javaDate = sdf.parse(d);
		//		java.sql.Date sqlDob = new java.sql.Date(javaDate.getTime());

		String[] ss=d.split("-");
		java.sql.Date sqlDob2= new java.sql.Date((Integer.valueOf(ss[0])-1900),Integer.valueOf(ss[1])-1,Integer.valueOf(ss[2]));
	

		Boolean r=Boolean.parseBoolean(req.getParameter("retired"));


		String s=req.getParameter("ssn");

		String e=req.getParameter("email");

		Homeowner h=new Homeowner(userId, n, l, sqlDob2, r, s, e);
		HomeownerBO hbo=new HomeownerBO();
		hbo.registerHomeowner(h);
		ses.setAttribute("currentHomeowner", h);
		res.sendRedirect("property");
	}

	private void showHomeowner(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/Homeowner.jsp");
		r.forward(req, res);

	}

	private void postLocation(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, SQLException, IOException, ServletException {

		String a1 = req.getParameter("addressLine1");
		//		System.out.println(a1);
		String a2 = req.getParameter("addressLine2");
		// System.out.println(a2);
		String c = req.getParameter("city");
		// System.out.println(c);
		String s = req.getParameter("state");
		// System.out.println(s);
		String z = req.getParameter("zip");
		// System.out.println(z);
		String t = req.getParameter("residenceType");
		// System.out.println(t);
		String use = req.getParameter("residenceUse");
		// System.out.println(use);

		HttpSession ses = req.getSession();
		User user = (User) ses.getAttribute("currentUser");
		int userId = user.getUserId();
		// System.out.println(userId);

		Location l = new Location(userId, t, a1, a2, c, s, z, use);
		LocationDAO lbo = new LocationDAO();
		int locid=lbo.registerLocation(l);
		// System.out.println("Location registration number is:"+conf);
		l.setLocationId(locid);
		ses.setAttribute("currentLocation", l);

		Location loc=(Location) ses.getAttribute("currentLocation");
		//int locid=loc.getLocationId();
		//System.out.println(loc.getAddressLine1());
		res.sendRedirect("homeowner");
		//		RequestDispatcher rd = req.getRequestDispatcher("homeowner");
		//		rd.forward(req, res);

	}

	private void showLocation(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/Location.jsp");
		r.forward(req, res);

	}

	private void showWelcome(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/WelcomePage.jsp");
		r.forward(req, res);

		// res.sendRedirect("/WEB-INF/views/WelcomePage.jsp");
	}

	private void postRegister(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, SQLException, IOException, ServletException {
		List<String> errorList = new ArrayList<>();
		String username = req.getParameter("userName");
		String pass = req.getParameter("pass");
		if (username.length() < 2 || username.length() > 50) {
			errorList.add("UserName should be between 3 and 50 charecters");
		}
		if (username.matches("[a-zA-Z0-9]+") == false) {
			errorList.add("UserName must only contain alphanumeric charecters");
		}
		if (pass.length() < 8 || pass.length() > 20) {
			errorList.add("Password should be between 8 and 20 charecters");
		}
		if (!pass.matches("[a-zA-Z0-9]+")) {
			errorList.add("Password must only contain alphanumeric charecters");
		}
		User u = new User();
		u.setUserName(username);
		u.setPassword(pass);
		UserBO ubo = new UserBO();

		if (errorList.isEmpty()) {
			int id = ubo.registerUser(u);
			System.out.println(id);
			// System.out.printf("Your ID: %d, your Username: %s, your Password: %s, your
			// admin status: %S\n",
			// u.getUserId(), u.getUserName(), u.getPassword(), u.getAdminRole());
			res.sendRedirect("showUserPage");
			System.out.println("you signed up");
		}

		else {
			req.setAttribute("errorList", errorList);
			RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/views/UserReg.jsp");
			rd.forward(req, res);
			System.out.println("you didnt sign up");
		}

	}

	private void showRegister(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/UserReg.jsp");
		r.forward(req, res);

	}

	private void postLogIn(HttpServletRequest req, HttpServletResponse res)
			throws ClassNotFoundException, IOException, SQLException, ServletException {
		HttpSession ses = req.getSession();

		String username = req.getParameter("userName");
		String pass = req.getParameter("pass");

		User u = new User();

		UserBO ubo = new UserBO();
		u = ubo.getUserByUser_Name(username);

		// UserDAO udao=new UserDAO();
		// u=udao.getUserByUser_Name(username);

		if (u == null) {
			errorList = new ArrayList<>();
			errorList.add("Invalid Login, wrong Password and/or Username");
			req.setAttribute("errorList", errorList);
			RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/UserLogIn.jsp");
			r.forward(req, res);
		} 
		else 
		{
			if (u.getPassword().equals(pass)) {
				ses.setAttribute("currentUser", u);
				// ses.setAttribute("username", username); then just ${username}
				// RequestDispatcher
				// r=req.getRequestDispatcher("/WEB-INF/views/WelcomePage.jsp");
				// r.forward(req, res);
				res.sendRedirect("welcomeUser");
			} 
			else {
				errorList = new ArrayList<>();
				errorList.add("Invalid Login, wrong Username and/or Password");
				req.setAttribute("errorList", errorList);
				RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/UserLogIn.jsp");
				r.forward(req, res);
			}
		}
	}

	private void showLogIn(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		RequestDispatcher r = req.getRequestDispatcher("/WEB-INF/views/UserLogIn.jsp");
		r.forward(req, res);
	}

	private void logOut(HttpServletRequest req, HttpServletResponse res) throws IOException {
		HttpSession ses = req.getSession();
		ses.invalidate();
		res.sendRedirect("showUserPage");

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
