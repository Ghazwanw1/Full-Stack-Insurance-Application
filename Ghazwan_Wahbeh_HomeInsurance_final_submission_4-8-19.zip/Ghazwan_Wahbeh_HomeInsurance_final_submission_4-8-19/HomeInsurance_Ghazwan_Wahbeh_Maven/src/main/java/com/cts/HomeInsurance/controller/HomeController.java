package com.cts.HomeInsurance.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cts.HomeInsurance.BO.PolicyBO;
import com.cts.HomeInsurance.BO.UserBO;
import com.cts.HomeInsurance.model.Policy;
import com.cts.HomeInsurance.model.User;





@Controller
@SessionAttributes
public class HomeController {
		List<String> errorList;


	@RequestMapping("/adminLogin")
	public String adminPage() {

		return "AdminPage";
	}


	@RequestMapping ("/login")
	public String loginUser(HttpSession ses, Model model, @RequestParam String userName, 
			@RequestParam String pass) throws ClassNotFoundException, IOException, SQLException {
		User u = new User();
		UserBO ubo = new UserBO();
		u = ubo.getUserByUser_Name(userName);
		

		if (u == null) {		
			errorList=new ArrayList<>();
			errorList.add("Invalid username and/or password, try agian..");
			ses.setAttribute("errorList", errorList);
			return "AdminPage";
		}

		else {
				if (u.getPassword().equals(pass) && u.getAdminRole().equalsIgnoreCase("admin"))
							{	
				ses.setAttribute("currentAdmin", u);
				return "Admin";
							}

				else 
					{
//					errorList = new ArrayList<>();
//					errorList.add("Invalid Login, wrong Username and/or Password");
//					ses.setAttribute("errorList", errorList);
						if (!u.getAdminRole().equalsIgnoreCase("admin"))
								{
							errorList=new ArrayList<>();
							errorList.add("You don't have Admin privileges");
							ses.setAttribute("errorList", errorList);
							return "AdminPage";
									}
						if (!u.getPassword().equals(pass))
						{	errorList=new ArrayList<>();
						errorList.add("Wrong password");
						ses.setAttribute("errorList", errorList);
						}	
						return "AdminPage";
						}
			}
	}


	@RequestMapping(value="/adminPolicy")
	public String searchPolicy(HttpSession ses, @RequestParam("searchUsername") String name)
			throws ClassNotFoundException, IOException, SQLException {

		PolicyBO pBO = new PolicyBO();

		List<Policy> pl=pBO.getAllPolicies(name);
		ses.setAttribute("policyList", pl);
//		for(Policy p:pl) {
//			System.out.println(p.getPolicyId());
//		}
		//		Policy p = pBO.getPolicyByUser_Name(name);
		//		ses.setAttribute("policy", p);

		ses.setAttribute("user",name);

		return "AdminPolicyView";
	}

	@RequestMapping("/adminLogout")
	public String logOut() {

		return "adminLogin";
	}

	@RequestMapping("/adminHome")
	public String home() {
		return "Admin";
	}

	@RequestMapping("/renewPolicy")
	public String renewPolicy(HttpSession ses, @RequestParam ("policyId") int pid) throws ClassNotFoundException, IOException, SQLException {
		
		PolicyBO pbo=new PolicyBO();
		pbo.renewPolicy(pbo.getPolicyById(pid));
		Policy p=pbo.getPolicyById(pid);
		ses.setAttribute("Policy", p);
		return "AdminRenew";

	}
	
	@RequestMapping("/cancelPolicy")
	public String cancelPolicy(HttpSession ses, @RequestParam ("policyId") int pid) throws ClassNotFoundException, IOException, SQLException {
		PolicyBO pbo=new PolicyBO();
		pbo.cancelPolicy(pbo.getPolicyById(pid));
		Policy p=pbo.getPolicyById(pid);
		ses.setAttribute("Policy", p);
		return "AdminCancel";
		
	}


}
