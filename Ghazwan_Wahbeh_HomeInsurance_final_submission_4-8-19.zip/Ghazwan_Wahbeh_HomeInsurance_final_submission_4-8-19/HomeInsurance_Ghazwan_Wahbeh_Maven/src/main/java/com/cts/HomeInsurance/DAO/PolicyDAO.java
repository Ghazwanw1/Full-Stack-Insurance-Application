package com.cts.HomeInsurance.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.HomeInsurance.model.Policy;


public class PolicyDAO {

	public List<Policy> getAllPolicies(String User_Name) throws SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Policy p = null;
		List<Policy> policyList = null;
		// Assign query string to a variable
		//
		//select * from policies inner join users on users.user_id=policies.user_id where user_name = ?
		String qString = "select * from policies inner join users on users.user_id=policies.user_id where user_name = ?";
		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = orcl.getConnection();
			// If the connection fails the application won't make it to this point
			System.out.println("Connected to database.");
			// Create Statement instance/object
			stmt = conn.prepareStatement(qString);

			// Run query and assign to ResultSet
			stmt.setString(1, User_Name);
			rs = stmt.executeQuery();
			//Create list to hold Policy objects
			policyList = new ArrayList<Policy>();
			// Read the ResultSet
			while (rs.next()) {
				// Each iteration creates a new Policy
				p = new Policy();
				// Assign columns/fields to related fields in the Policy object
				// 1,2,3,4,5,6 and 4 represent column numbers/positions
				p.setPolicyId(rs.getInt(1));
				p.setQuoteId(rs.getInt(2));
				p.setUserId(rs.getInt(3));
				p.setEffectiveDate(rs.getDate(4));
				p.setEndDate(rs.getDate(5));
				p.setTerm(rs.getInt(6));
				
				
				p.setPolicyStatus(rs.getString(7));
				
				// Add the Policy to the list
				policyList.add(p);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)

			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return policyList;
	} // End of getAllPolicies method

	
	
	//getting record by id
		public Policy getPolicyByUser_Name(String User_Name) throws ClassNotFoundException, IOException, SQLException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Policy p = null;
			String qString=null;

			// Assign query string to variable
			
			qString = new String();
			qString="select * from policies inner join users on users.user_id=policies.user_id where user_name = ?";

			// Create OracleConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setString(1, User_Name); // user_name if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new Policy
			if (rs.next()) {
			p = new Policy();
			p.setPolicyId(rs.getInt(1));
			p.setQuoteId(rs.getInt(2));
			p.setUserId(rs.getInt(3));
			p.setEffectiveDate(rs.getDate(4));
			p.setEndDate(rs.getDate(5));
			p.setTerm(rs.getInt(6));
			p.setPolicyStatus(rs.getString(7));
			
			}
			}
			catch (ClassNotFoundException | IOException | SQLException e)
			{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			}
			finally
			{
			if (rs != null) {
			rs.close();
			}
			if (stmt != null) {
			stmt.close();
			}
			if (conn != null) {
			conn.close();
			}
			}
			
			return p;
			} // End of getHomeownerById() method

		//****************registerPolicy() method*****************
		public Integer registerPolicy(Policy policy) throws SQLException, ClassNotFoundException, IOException
		{
		// Declare variables
			
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		// Assign insert statement string to variable
		
		String insertString = "insert into policies (QUOTE_ID, USER_ID, EFFECTIVE_DATE, END_DATE, TERM, POLICY_STATUS) values (?,?,?,?,?,?)";
		int ID = -1;
		String[] COL = {"POLICY_ID"};
		OracleConnection orcl = new OracleConnection();
		try
		{
		conn = orcl.getConnection();
		stmt = conn.prepareStatement(insertString, COL);
		//stmt.setInt(1,policy.getPolicyId());
		stmt.setInt(1, policy.getQuoteId());
		stmt.setInt(2, policy.getUserId());
		stmt.setDate(3, (Date) policy.getEffectiveDate());
		stmt.setDate(4, (Date) policy.getEndDate());
		stmt.setInt(5, policy.getTerm());
		stmt.setString(6, policy.getPolicyStatus());
		
		stmt.executeUpdate();
		
		rs = stmt.getGeneratedKeys();
		if(rs != null && rs.next()) {
		ID = rs.getInt(1);
		}
		
		System.out.println(ID);
		}
		catch (SQLException e)
		{
		System.out.println("Error: " + e.getMessage());
		}
		finally
		{
		if (rs != null) {
		rs.close();
		}
		if (stmt != null) {
		stmt.close();
		}
		if (conn != null) {
		conn.close();
		}
		}
		return ID;
		} 
		// End of registerPolicy() method
		
		public Policy getPolicyById(int policyId) throws ClassNotFoundException, IOException, SQLException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Policy p = null;
			
			// Assign query string to variable
			String qString = "select * from policies where policy_id = ?";
			
			// Create MySqlConnection class instance
			OracleConnection orcl = new OracleConnection();
			
			// Begin try/catch block to query the database
			try
			{
				// Connect to database and assign query string to PreparedStatement object
				conn = orcl.getConnection();
				stmt = conn.prepareStatement(qString);
				
				// Set query parameters (?)
				stmt.setInt(1, policyId); // user_id if from String parameter passed to method
				
				// Run query and assign to ResultSet
				rs = stmt.executeQuery();
				
				// Retrieve ResultSet and assign to new User
				if (rs.next()) {
					p = new Policy();
					p.setPolicyId(rs.getInt(1));
					p.setQuoteId(rs.getInt(2));
					p.setUserId(rs.getInt(3));
					p.setEffectiveDate(rs.getDate(4));
					p.setEndDate(rs.getDate(5));
					p.setTerm(rs.getInt(6));
					p.setPolicyStatus(rs.getString(7));
				}
			}
			catch (ClassNotFoundException | IOException | SQLException e)
			{
				System.out.println("Error: " + e.getMessage());
				e.getStackTrace();
			}
			finally
			{
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			return p;
		}
		
		
		public Boolean renewPolicy(Policy p) throws SQLException, ClassNotFoundException, IOException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			Integer updateResult = null;
			
			// Assign update string to variable
			String updateString = "update policies "
					+ "set term = term+1, policy_status = 'RENEWED', end_date=add_months(effective_date, 12) "
					+ "where policy_id = ?";
			
			// Create MySqlConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
				// Connect to database and assign query string to PreparedStatement object
				conn = orcl.getConnection();
				stmt = conn.prepareStatement(updateString);
				
				// Set query parameters (?)
				stmt.setInt(1, p.getPolicyId());
				
				// Run query and assign to ResultSet
				updateResult = stmt.executeUpdate();
			}
			catch (ClassNotFoundException | SQLException e)
			{
				System.out.println("Error: " + e.getMessage());
			}
			finally
			{
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			if (updateResult > 0) {
				return true;
			}
			return false;
		}
		
		
		
		public Boolean cancelPolicy(Policy p) throws SQLException, ClassNotFoundException, IOException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			Integer updateResult = null;
			
			// Assign update string to variable
			String updateString = "update policies "
					+ "set term = 0, policy_status = 'CANCELLED', end_date=effective_date "
					+ "where policy_id = ?";
			
			// Create MySqlConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
				// Connect to database and assign query string to PreparedStatement object
				conn = orcl.getConnection();
				stmt = conn.prepareStatement(updateString);
				
				// Set query parameters (?)
				stmt.setInt(1, p.getPolicyId());
				
				// Run query and assign to ResultSet
				updateResult = stmt.executeUpdate();
			}
			catch (ClassNotFoundException | SQLException e)
			{
				System.out.println("Error: " + e.getMessage());
			}
			finally
			{
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			}
			if (updateResult > 0) {
				return true;
			}
			return false;
		}
		
		
		public Policy renewPolicy(int pid)throws SQLException, IOException, ClassNotFoundException
		{	
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			OracleConnection orcl=new OracleConnection();
			Policy newp=new Policy();
			
			String updateString= "UPDATE POLICIES "
								+"SET TERM = TERM+1, "
								+ "POLICY_STATUS = 'RENEWED'"
								+ "WHERE POLICY_ID = ?";
			try 
			{
				conn=orcl.getConnection();
				
				stmt=conn.prepareStatement(updateString);
				
				
				stmt.setInt(1, pid);
				
				 //rs = stmt.getGeneratedKeys();
				//rs= stmt.getResultSet();
				
				
				rs = stmt.executeQuery();
				System.out.println(rs.rowUpdated());
			    
				if(rs != null && rs.next()) {
				Policy	p=new Policy();
				p.setPolicyId(rs.getInt(1));
				p.setQuoteId(rs.getInt(2));
				p.setUserId(rs.getInt(3));
				p.setEffectiveDate(rs.getDate(4));
				p.setEndDate(rs.getDate(5));
				p.setTerm(rs.getInt(6));
				p.setPolicyStatus(rs.getString(7));
				
				newp=p;
				
				System.out.println("kjkjd");
				}
				}
				catch (ClassNotFoundException | IOException | SQLException e)
				{
				System.out.println("Error: " + e.getMessage());
				e.getStackTrace();
				}
				finally
				{				
					if (rs != null) {
						rs.close();
					}
					if (stmt != null) {
						stmt.close();
					}
					if (conn != null) {
						conn.close();
					}
				}
				
			return newp;
				} 

	
}
