package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.UserDAO;
import com.cts.HomeInsurance.model.User;

public class UserBO {
	public List<User> getAllUsers() throws SQLException {
		List<User> userList = null;
		UserDAO usdao=new UserDAO();
		usdao.getAllUsers();
		return userList;
	}
	
	public User getUserByUser_Name(String User_Name) throws ClassNotFoundException, IOException, SQLException{
	
		User u = new User();
		UserDAO usdao=new UserDAO();
		u=usdao.getUserByUser_Name(User_Name);
		return u;
	}
	
	public Integer registerUser(User user) throws ClassNotFoundException, SQLException, IOException {
		UserDAO usdao=new UserDAO();
		int ID = usdao.registerUser(user);
		
		return ID;
	}
}
