package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.QuoteDAO;
import com.cts.HomeInsurance.model.Quote;

public class QuoteBo {

	public List<Quote> getAllQuotes(int userId) throws SQLException {
		List<Quote> quoteList = null;
		QuoteDAO qtdao=new QuoteDAO();
		quoteList=qtdao.getAllQuotes(userId);
		return quoteList;
	}
	
	public Quote getQuoteByLocation_Id(int Location_Id) throws ClassNotFoundException, IOException, SQLException{
		QuoteDAO qtdao=new QuoteDAO();
		Quote q = new Quote();
		q=qtdao.getQuoteByLocation_Id(Location_Id);
		return q;
	}
	
	public Integer registerQuote(Quote quote) throws ClassNotFoundException, SQLException, IOException {
		QuoteDAO qtdao=new QuoteDAO();
		int ID=qtdao.registerQuote(quote);
		
		return ID;
	}
	public Quote getQuoteById(int quoteId) throws ClassNotFoundException, IOException, SQLException{
		QuoteDAO qtdao=new QuoteDAO();
		Quote q = new Quote();
		q=qtdao.getQuoteById(quoteId);
		return q;
	}
}
