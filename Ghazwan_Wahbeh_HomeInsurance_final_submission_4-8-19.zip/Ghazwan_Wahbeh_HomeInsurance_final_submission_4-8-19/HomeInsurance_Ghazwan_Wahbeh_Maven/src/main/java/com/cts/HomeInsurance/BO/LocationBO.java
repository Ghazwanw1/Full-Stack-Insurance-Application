package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.LocationDAO;
import com.cts.HomeInsurance.model.Location;

public class LocationBO {

	public List<Location> getAllLocations() throws SQLException {
		List<Location> locationList = null;
		LocationDAO locdao=new LocationDAO();
		locdao.getAllLocations();
		return locationList;
	}
	
	public Location getLocationByUser_Id(int UserUser_Id) throws ClassNotFoundException, IOException, SQLException{
		LocationDAO locdao=new LocationDAO();
		Location u = new Location();
		u=locdao.getLocationByUser_Id(UserUser_Id);
		return u;
	}
	
	public Integer registerLocation(Location loc) throws ClassNotFoundException, SQLException, IOException {
		LocationDAO locdao=new LocationDAO();
		Integer ID=locdao.registerLocation(loc);
	
		return ID;
	}
	public Location getLocationQuote_Id(int quoteId) throws ClassNotFoundException, IOException, SQLException{
		LocationDAO locdao=new LocationDAO();
		Location u = new Location();
		u=locdao.getLocationByQuoteId(quoteId);
		return u;
	}
	
	
//	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
//		LocationBO l_bo = new LocationBO();
//		Location l = new Location();
//		l.setUserId(60);
//		l.setAddressLine1("2345");
//		l.setAddressLine2("34534");
//		l.setCity("Dallas");
//		l.setLocationState("TX");
//		l.setResidenceType("Single Story");
//		l.setResidenceUse("Primary");
//		l.setZipCode("77777");
//		
//		Integer ID = l_bo.registerLocation(l);
//		System.out.println(l.getLocationId());
//		System.out.println(l_bo.getLocationByUser_Id(ID).getLocationId());
//		System.out.println(l.getUserId());
//	}
}
