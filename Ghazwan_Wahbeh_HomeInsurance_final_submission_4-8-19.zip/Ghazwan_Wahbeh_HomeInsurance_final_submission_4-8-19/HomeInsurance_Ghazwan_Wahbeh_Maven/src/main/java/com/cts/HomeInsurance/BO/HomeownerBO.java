package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.HomeownerDAO;
import com.cts.HomeInsurance.model.Homeowner;

public class HomeownerBO {
	
	public List<Homeowner> getAllHomeowners() throws SQLException{
		List<Homeowner> homeownerList = null;
		HomeownerDAO hodao=new HomeownerDAO();
		hodao.getAllHomeowners();
		return homeownerList;
	}
	
	public Homeowner getHomeownerByUser_Id(int User_Id) throws ClassNotFoundException, IOException, SQLException{
		HomeownerDAO hodao=new HomeownerDAO();
		Homeowner u = new Homeowner();
		u=hodao.getHomeownerByUser_Id(User_Id);
		return u;
	}

	public Integer registerHomeowner(Homeowner homeowner) throws ClassNotFoundException, SQLException, IOException {
		HomeownerDAO hodao=new HomeownerDAO();
		int ID =hodao.registerHomeowner(homeowner);
		
		return ID;
	}


}
