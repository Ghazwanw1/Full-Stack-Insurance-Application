package com.cts.HomeInsurance.DAO;

import java.sql.Statement;
import java.util.ArrayList;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import com.cts.HomeInsurance.model.Homeowner;


public class HomeownerDAO {

	public List<Homeowner> getAllHomeowners() throws SQLException {
		// Declare variables
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Homeowner h = null;
		List<Homeowner> homeownerList = null;
		// Assign query string to a variable
		String qString = "select * from homeowners";
		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = orcl.getConnection();
                        // If the connection fails the application won't make it to this point
			System.out.println("Connected to database.");
                        // Create Statement instance/object
			stmt = conn.createStatement();
			
			// Run query and assign to ResultSet
			rs = stmt.executeQuery(qString);
                        //Create list to hold Homeowner objects
			homeownerList = new ArrayList<Homeowner>();
			// Read the ResultSet
			while (rs.next()) {
				// Each iteration creates a new Homeowner
				h = new Homeowner();
				// Assign columns/fields to related fields in the Homeowner object
                                // 1,2,3,4,5,6 and 7 represent column numbers/positions
				h.setUserId(rs.getInt(1));
				h.setFirstName(rs.getString(2));
				h.setLastName(rs.getString(3));
				h.setDob(rs.getDate(4));
				h.setRetiredStatus(rs.getBoolean(5));
				h.setSsn(rs.getString(6));
				h.setEmail(rs.getString(7));
				
				// Add the Homeowner to the list
				homeownerList.add(h);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)
				
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return homeownerList;
	} // End of getAllHomeowners method
	
	
	//****************registerHomeowner() method*****************
	public Integer registerHomeowner(Homeowner homeowner) throws SQLException, ClassNotFoundException, IOException
	{
	// Declare variables
		
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	// Assign insert statement string to variable
	
	String insertString = "insert into homeowners (USER_ID, FIRST_NAME, LAST_NAME, DOB, RETIRED_STATUS, SSN, EMAIL) values (?,?,?,?,?,?,?)";
	int ID = -1;
	String[] COL = {"USER_ID"};
	OracleConnection orcl = new OracleConnection();
	try
	{
	conn = orcl.getConnection();
	stmt = conn.prepareStatement(insertString, COL);
	stmt.setInt(1,homeowner.getUserId());
	stmt.setString(2, homeowner.getFirstName());
	stmt.setString(3, homeowner.getLastName());
	stmt.setDate(4, (java.sql.Date) homeowner.getDob());
	stmt.setBoolean(5,homeowner.isRetiredStatus());
	
	stmt.setString(6, homeowner.getSsn());
	stmt.setString(7, homeowner.getEmail());
	stmt.executeUpdate();
	rs = stmt.getGeneratedKeys();
	if(rs != null && rs.next()) {
	ID = rs.getInt(1);
	}
	
	System.out.println(ID);
	}
	catch (SQLException e)
	{
	System.out.println("Error: " + e.getMessage());
	}
	finally
	{
	if (rs != null) {
	rs.close();
	}
	if (stmt != null) {
	stmt.close();
	}
	if (conn != null) {
	conn.close();
	}
	}
	return ID;
	} // End of registerHomeowner() method
	
//getting record by id
	public Homeowner getHomeownerByUser_Id(int HomeownerUser_Id) throws ClassNotFoundException, IOException, SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Homeowner u = null;
		String qString=null;

		// Assign query string to variable
		
		qString = new String();
		qString="select * from homeowners where user_id = ?";

		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
		// Connect to database and assign query string to PreparedStatement object
		conn = orcl.getConnection();
		stmt = conn.prepareStatement(qString);
		// Set query parameters (?)
		stmt.setInt(1, HomeownerUser_Id); // user_id if from String parameter passed to method
		// Run query and assign to ResultSet
		rs = stmt.executeQuery();
		// Retrieve ResultSet and assign to new Homeowner
		if (rs.next()) {
		u = new Homeowner();
		u.setUserId(rs.getInt(1));
		u.setFirstName(rs.getString(2));
		u.setLastName(rs.getString(3));
		u.setDob(rs.getDate(4));
		u.setRetiredStatus(rs.getBoolean(5));
		
		u.setSsn(rs.getString(6));
		u.setEmail(rs.getString(7));
		}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
		System.out.println("Error: " + e.getMessage());
		e.getStackTrace();
		}
		finally
		{
		if (rs != null) {
		rs.close();
		}
		if (stmt != null) {
		stmt.close();
		}
		if (conn != null) {
		conn.close();
		}
		}
		return u;
		} // End of getHomeownerById() method


}




