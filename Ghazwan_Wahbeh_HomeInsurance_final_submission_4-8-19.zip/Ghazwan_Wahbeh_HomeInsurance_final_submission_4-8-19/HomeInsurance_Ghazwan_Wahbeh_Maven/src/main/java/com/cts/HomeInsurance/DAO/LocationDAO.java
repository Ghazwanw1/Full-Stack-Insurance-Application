package com.cts.HomeInsurance.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.HomeInsurance.model.Location;;

public class LocationDAO {

	public List<Location> getAllLocations() throws SQLException {
		// Declare variables
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Location loc = null;
		List<Location> locationList = null;
		// Assign query string to a variable
		String qString = "select * from locations";
		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = orcl.getConnection();
			// If the connection fails the application won't make it to this point
			System.out.println("Connected to database.");
			// Create Statement instance/object
			stmt = conn.createStatement();

			// Run query and assign to ResultSet
			rs = stmt.executeQuery(qString);
			//Create list to hold Location objects
			locationList = new ArrayList<Location>();
			// Read the ResultSet
			while (rs.next()) {
				// Each iteration creates a new Location
				loc = new Location();
				// Assign columns/fields to related fields in the Location object
				// 1,2,3,4,5,6,7,8 and 9 represent column numbers/positions
				loc.setLocationId(rs.getInt(1));
				loc.setUserId(rs.getInt(2));
				loc.setResidenceType(rs.getString(3));
				loc.setAddressLine1(rs.getString(4));
				loc.setAddressLine2(rs.getString(5));
				loc.setCity(rs.getString(6));
				loc.setLocationState(rs.getString(7));
				loc.setZipCode(rs.getString(8));
				loc.setResidenceUse(rs.getString(9));

				// Add the Location to the list
				locationList.add(loc);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)

			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return locationList;
	} // End of getAllLocations method



	//getting record by id
	public Location getLocationByUser_Id(int User_Id) throws ClassNotFoundException, IOException, SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Location loc = null;
		String qString=null;

		// Assign query string to variable

		qString = new String();
		qString="select * from locations where user_id = ?";

		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setInt(1, User_Id); // user_id if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new Location
			if (rs.next()) {
				loc = new Location();
				loc.setLocationId(rs.getInt(1));
				loc.setUserId(rs.getInt(2));
				loc.setResidenceType(rs.getString(3));
				loc.setAddressLine1(rs.getString(4));
				loc.setAddressLine2(rs.getString(5));
				loc.setCity(rs.getString(6));
				loc.setLocationState(rs.getString(7));
				loc.setZipCode(rs.getString(8));
				loc.setResidenceUse(rs.getString(9));
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return loc;
	} // End of getHomeownerById() method

	//****************registerLocation() method*****************
	public Integer registerLocation(Location loc) throws SQLException, ClassNotFoundException, IOException
	{
		// Declare variables

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		// Assign insert statement string to variable

		String insertString = "insert into locations (USER_ID, RESIDENCE_TYPE, ADDRESS_LINE_1, ADDRESS_LINE_2, CITY, LOCATION_STATE, ZIP_CODE, RESIDENCE_USE) values (?,?,?,?,?,?,?,?)";
		int ID = -1;
		String[] COL = {"LOCATION_ID"};
		OracleConnection orcl = new OracleConnection();

		try
		{
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(insertString, COL);
			//	stmt.setInt(1,loc.getLocationId());
			stmt.setInt(1,loc.getUserId());
			stmt.setString(2, loc.getResidenceType());
			stmt.setString(3, loc.getAddressLine1());
			stmt.setString(4, loc.getAddressLine2());
			stmt.setString(5, loc.getCity());
			stmt.setString(6, loc.getLocationState());
			stmt.setString(7, loc.getZipCode());
			stmt.setString(8, loc.getResidenceUse());
			stmt.executeUpdate();
			rs = stmt.getGeneratedKeys();

			if(rs != null && rs.next()) {
				ID = rs.getInt(1);

			}

			System.out.println(ID);
		}
		catch (SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return ID;
	} 
	
	
	
	public Location getLocationByQuoteId(int quoteId) throws ClassNotFoundException, IOException, SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Location loc = null;
		String qString=null;

		// Assign query string to variable

		qString = new String();
		qString="select * from locations inner join quotes on locations.location_id=quotes.location_id where quote_id =?";

		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setInt(1, quoteId); // user_id if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new Location
			if (rs.next()) {
				loc = new Location();
				loc.setLocationId(rs.getInt(1));
				loc.setUserId(rs.getInt(2));
				loc.setResidenceType(rs.getString(3));
				loc.setAddressLine1(rs.getString(4));
				loc.setAddressLine2(rs.getString(5));
				loc.setCity(rs.getString(6));
				loc.setLocationState(rs.getString(7));
				loc.setZipCode(rs.getString(8));
				loc.setResidenceUse(rs.getString(9));
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return loc;
	}
	
	
	
	
	
	
	// End of registerLocation() method
	
//	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
//		LocationDAO l_dao = new LocationDAO();
//		Location l = new Location();
//		l.setUserId(60);
//		l.setAddressLine1("2345");
//		l.setAddressLine2("34534");
//		l.setCity("Dallas");
//		l.setLocationState("TX");
//		l.setResidenceType("Single Story");
//		l.setResidenceUse("Primary");
//		l.setZipCode("77777");
//		
//		Integer id = l_dao.registerLocation(l);
//		System.out.println("ID: " + id);
//	}

}
