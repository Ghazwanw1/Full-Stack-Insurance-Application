package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.PolicyDAO;
import com.cts.HomeInsurance.model.Policy;



public class PolicyBO {

	public List<Policy> getAllPolicies(String User_Name) throws SQLException {
		List<Policy> policyList = null;
		PolicyDAO pdao=new PolicyDAO();
		//policyList=pdao.getAllPolicies(String User_Name));
		policyList=pdao.getAllPolicies(User_Name);
		return policyList;
	}
	
	public Policy getPolicyByUser_Name(String User_Name) throws ClassNotFoundException, IOException, SQLException{
		PolicyDAO pdao=new PolicyDAO();
		Policy p = new Policy();
		p=pdao.getPolicyByUser_Name(User_Name);
		
		return p;
	}
	
	public Integer registerPolicy(Policy policy) throws ClassNotFoundException, SQLException, IOException {
		PolicyDAO pdao=new PolicyDAO();
		int ID =pdao.registerPolicy(policy);
		 
		return ID;
	}
	public boolean renewPolicy(Policy pol) throws ClassNotFoundException, SQLException, IOException
	{
		PolicyDAO polDAO = new PolicyDAO();
		return polDAO.renewPolicy(pol);
		
	}
	public boolean cancelPolicy(Policy pol) throws ClassNotFoundException, SQLException, IOException
	{
		PolicyDAO polDAO = new PolicyDAO();
		return polDAO.cancelPolicy(pol);
		
	}
	public Policy getPolicyById(int pId) throws ClassNotFoundException, IOException, SQLException{
		PolicyDAO pdao=new PolicyDAO();
		Policy p = new Policy();
		p=pdao.getPolicyById(pId);
		
		return p;
	}
}
