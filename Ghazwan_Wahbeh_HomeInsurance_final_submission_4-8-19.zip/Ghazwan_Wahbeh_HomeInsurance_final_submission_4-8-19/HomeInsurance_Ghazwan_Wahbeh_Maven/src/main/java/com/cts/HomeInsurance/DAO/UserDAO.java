package com.cts.HomeInsurance.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.HomeInsurance.model.User;

public class UserDAO {
	

	public List<User> getAllUsers() throws SQLException {
		// Declare variables
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		User u = null;
		List<User> userList = null;
		// Assign query string to a variable
		String qString = "select * from users";
		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = orcl.getConnection();
			// If the connection fails the application won't make it to this point
			System.out.println("Connected to database.");
			// Create Statement instance/object
			stmt = conn.createStatement();

			// Run query and assign to ResultSet
			rs = stmt.executeQuery(qString);
			//Create list to hold User objects
			userList = new ArrayList<User>();
			// Read the ResultSet
			while (rs.next()) {
				// Each iteration creates a new User
				u = new User();
				// Assign columns/fields to related fields in the User object
				// 1,2,3 and 4 represent column numbers/positions
				u.setUserId(rs.getInt(1));
				u.setUserName(rs.getString(2));
				u.setPassword(rs.getString(3));
				u.setAdminRole(rs.getString(4));



				// Add the User to the list
				userList.add(u);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)

			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return userList;
	} // End of getAllUsers method

	
	
	//getting record by username
		public User getUserByUser_Name(String User_Name) throws ClassNotFoundException, IOException, SQLException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			User u = null;
			String qString=null;

			// Assign query string to variable
			
			qString = new String();
			qString="select * from users where user_name = ?";

			// Create OracleConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setString(1, User_Name); // user_id if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new User
			if (rs.next()) {
			u = new User();
			u.setUserId(rs.getInt(1));
			u.setUserName(rs.getString(2));
			u.setPassword(rs.getString(3));
			u.setAdminRole(rs.getString(4));
			}
			}
			catch (ClassNotFoundException | IOException | SQLException e)
			{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			}
			finally
			{
			if (rs != null) {
			rs.close();
			}
			if (stmt != null) {
			stmt.close();
			}
			if (conn != null) {
			conn.close();
			}
			}
			return u;
			} // End of getHomeownerById() method

		//****************registerUser() method*****************
		public Integer registerUser(User user) throws SQLException, ClassNotFoundException, IOException
		{
		// Declare variables
			
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		// Assign insert statement string to variable
		
//		String insertString = "insert into users (USER_ID, USER_NAME, PASSWORD, ADMIN_ROLE) values (?,?,?,?)";
		String insertString = "insert into users (USER_NAME, PASSWORD) values (?,?)";
		int ID = -1;
		String[] COL = {"USER_ID"};
		OracleConnection orcl = new OracleConnection();
		try
		{
		conn = orcl.getConnection();
		stmt = conn.prepareStatement(insertString, COL);
		//stmt.setInt(1,user.getUserId());
		stmt.setString(1, user.getUserName());
		stmt.setString(2, user.getPassword());
		//stmt.setString(4, user.getAdminRole());
		stmt.executeUpdate();
		rs = stmt.getGeneratedKeys();
		if(rs != null && rs.next()) {
		ID = rs.getInt(1);
		}
		
		System.out.println(ID);
		}
		catch (SQLException e)
		{
		System.out.println("Error: " + e.getMessage());
		}
		finally
		{
		if (rs != null) {
		rs.close();
		}
		if (stmt != null) {
		stmt.close();
		}
		if (conn != null) {
		conn.close();
		}
		}
		return ID;
		} 
		// End of registerUser() method

}
