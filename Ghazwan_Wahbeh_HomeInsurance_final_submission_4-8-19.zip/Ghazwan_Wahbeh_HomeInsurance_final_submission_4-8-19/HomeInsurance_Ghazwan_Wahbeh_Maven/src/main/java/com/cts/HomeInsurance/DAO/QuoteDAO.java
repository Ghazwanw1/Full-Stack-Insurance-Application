package com.cts.HomeInsurance.DAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cts.HomeInsurance.model.Quote;



public class QuoteDAO {

	public List<Quote> getAllQuotes(int userId) throws SQLException {
		// Declare variables
		PreparedStatement stmt=null;
		Connection conn = null;
		//Statement stmt = null;
		ResultSet rs = null;
		Quote q = null;
		List<Quote> quoteList = null;
		// Assign query string to a variable
		String qString = "select * from quotes inner join locations on quotes.location_id=locations.location_id where user_id=?";
		// Create OracleConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = orcl.getConnection();
			// If the connection fails the application won't make it to this point
			System.out.println("Connected to database.");
			// Create Statement instance/object
			//stmt = conn.createStatement();
			stmt = conn.prepareStatement(qString);
			stmt.setInt(1, userId);;
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			//Create list to hold Quote objects
			quoteList = new ArrayList<Quote>();
			// Read the ResultSet
			while (rs.next()) {
				// Each iteration creates a new Quote
				q = new Quote();
				// Assign columns/fields to related fields in the Quote object
				// 1,2,3,4,5,6,7,8 and 9 represent column numbers/positions
				q.setQuoteId(rs.getInt(1));
				q.setLocationId(rs.getInt(2));
				q.setMonthlyPremium(rs.getFloat(3));
				q.setDwellingCoverage(rs.getFloat(4));
				q.setDetatchedStructures(rs.getFloat(5));
				q.setPersonalProperty(rs.getFloat(6));
				q.setAddLivingExp(rs.getFloat(7));
				q.setMedicalExpenses(rs.getFloat(8));
				q.setDeductible(rs.getFloat(9));
				

				// Add the Quote to the list
				quoteList.add(q);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)

			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return quoteList;
	} // End of getAllQuotes method

	
	
	//getting record by locationid
		public Quote getQuoteByLocation_Id(int Location_Id) throws ClassNotFoundException, IOException, SQLException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Quote q = null;
			String qString=null;

			// Assign query string to variable
			
			qString = new String();
			qString="select * from quotes where location_id = ?";

			// Create OracleConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setInt(1, Location_Id); // user_id if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new Quote
			if (rs.next()) {
			q = new Quote();
			
			q.setQuoteId(rs.getInt(1));
			q.setLocationId(rs.getInt(2));
			q.setMonthlyPremium(rs.getFloat(3));
			q.setDwellingCoverage(rs.getFloat(4));
			q.setDetatchedStructures(rs.getFloat(5));
			q.setPersonalProperty(rs.getFloat(6));
			q.setAddLivingExp(rs.getFloat(7));
			q.setMedicalExpenses(rs.getFloat(8));
			q.setDeductible(rs.getFloat(9));
			
			}
			}
			catch (ClassNotFoundException | IOException | SQLException e)
			{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			}
			finally
			{
			if (rs != null) {
			rs.close();
			}
			if (stmt != null) {
			stmt.close();
			}
			if (conn != null) {
			conn.close();
			}
			}
			return q;
			} // End of getHomeownerById() method

		//****************registerQuote() method*****************
		public Integer registerQuote(Quote quote) throws SQLException, ClassNotFoundException, IOException
		{
		// Declare variables
			
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		// Assign insert statement string to variable
		
		String insertString = "insert into quotes (LOCATION_ID, MONTHLY_PREMIUM, DWELLING_COVERAGE, DETATCHED_STRUCTURES, PERSONAL_PROPERTY, ADD_LIVING_EXP, MEDICAL_EXPENSES, DEDUCTIBLE) values (?,?,?,?,?,?,?,?)";
		int ID = -1;
		String[] COL = {"QUOTE_ID"};
		OracleConnection orcl = new OracleConnection();
		try
		{
		conn = orcl.getConnection();
		stmt = conn.prepareStatement(insertString, COL);
		//stmt.setInt(1, quote.getQuoteId());
		stmt.setInt(1, quote.getLocationId());
		stmt.setFloat(2, quote.getMonthlyPremium());
		stmt.setFloat(3, quote.getDwellingCoverage());
		stmt.setFloat(4, quote.getDetatchedStructures());
		stmt.setFloat(5,quote.getPersonalProperty());
		stmt.setFloat(6, quote.getAddLivingExp());
		stmt.setFloat(7, quote.getMedicalExpenses());
		stmt.setFloat(8, quote.getDeductible());
		
		stmt.executeUpdate();
		rs = stmt.getGeneratedKeys();
		if(rs != null && rs.next()) {
		ID = rs.getInt(1);
		}
		
		System.out.println(ID);
		}
		catch (SQLException e)
		{
		System.out.println("Error: " + e.getMessage());
		}
		finally
		{
		if (rs != null) {
		rs.close();
		}
		if (stmt != null) {
		stmt.close();
		}
		if (conn != null) {
		conn.close();
		}
		}
		return ID;
		} 
		
		
		
		
		
		public Quote getQuoteById(int quoteId) throws ClassNotFoundException, IOException, SQLException {
			// Declare variables
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet rs = null;
			Quote q = null;
			String qString=null;

			// Assign query string to variable
			
			qString = new String();
			qString="select * from quotes where quote_id = ?";

			// Create OracleConnection class instance
			OracleConnection orcl = new OracleConnection();
			// Begin try/catch block to query the database
			try
			{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(qString);
			// Set query parameters (?)
			stmt.setInt(1, quoteId); // user_id if from String parameter passed to method
			// Run query and assign to ResultSet
			rs = stmt.executeQuery();
			// Retrieve ResultSet and assign to new Quote
			if (rs.next()) {
			q = new Quote();
			
			q.setQuoteId(rs.getInt(1));
			q.setLocationId(rs.getInt(2));
			q.setMonthlyPremium(rs.getFloat(3));
			q.setDwellingCoverage(rs.getFloat(4));
			q.setDetatchedStructures(rs.getFloat(5));
			q.setPersonalProperty(rs.getFloat(6));
			q.setAddLivingExp(rs.getFloat(7));
			q.setMedicalExpenses(rs.getFloat(8));
			q.setDeductible(rs.getFloat(9));
			
			}
			}
			catch (ClassNotFoundException | IOException | SQLException e)
			{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
			}
			finally
			{
			if (rs != null) {
			rs.close();
			}
			if (stmt != null) {
			stmt.close();
			}
			if (conn != null) {
			conn.close();
			}
			}
			return q;
			}
		
		
		
		
		
		
		
		
		// End of registerQuote() method
//		public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
//			QuoteDAO qdao=new QuoteDAO();
//			Quote q=new Quote();
//			q.setLocationId(184);
//			q.setAddLivingExp(1);
//			q.setDeductible(2);
//			q.setDetatchedStructures(3);
//			q.setDwellingCoverage(4);
//			q.setMonthlyPremium(5);
//			q.setPersonalProperty(6);
//			q.setMedicalExpenses(7);
//			int i=qdao.registerQuote(q);
//			System.out.println(i);
//			
//		}
//	
}
