package com.cts.HomeInsurance.BO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cts.HomeInsurance.DAO.PropertyDAO;
import com.cts.HomeInsurance.model.Property;

public class PropertyBO {
	
	
	public List<Property> getAllProperties() throws SQLException {
		List<Property> propertyList = null;
		PropertyDAO prdao=new PropertyDAO();
		prdao.getAllProperties();
		return propertyList;
	}
	
	public Property getPropertyByLocation_Id(int Location_Id) throws ClassNotFoundException, IOException, SQLException{
		PropertyDAO prdao=new PropertyDAO();
		Property p = new Property();
		p=prdao.getPropertyByLocation_Id(Location_Id);
		return p;
	}
	
	public Integer registerProperty(Property property) throws ClassNotFoundException, SQLException, IOException {
		PropertyDAO prdao=new PropertyDAO();
		int ID =prdao.registerProperty(property);
		
		return ID;
	}

}
