package com.cts.HomeInsurance.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.apache.commons.io.FileUtils;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetQuoteStepDefinition {

	private static WebDriver d;

	private void takeScreenShot(WebDriver driver) throws IOException {
	    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
	}
	
	@Given("^Registred User navigates to homeinsurance website$")
    public void registred_user_navigates_to_homeinsurance_website() throws Throwable {
		System.setProperty("webdriver.chrome.driver", 
				"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		d = new ChromeDriver();
		d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		d.manage().window().maximize();
		takeScreenShot(d);
    }

    @Then("^User gets to coverage details and views his quote and logout$")
    public void user_gets_to_coverage_details_and_views_his_quote_and_logout() throws Throwable {
    	
       assertThat(d.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]")).getText(), equalTo("5.35"));
       d.findElement(By.xpath("/html/body/header/a[5]")).click();
       takeScreenShot(d);
       d.close();
    }

    @And("^User login with his username and password$")
    public void user_login_with_his_username_and_password() throws Throwable {
        d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
        d.findElement(By.name("pass")).sendKeys("MikePassword");
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form/div[3]/input")).click();
       
    }

    @And("^User clicks getquote button$")
    public void user_clicks_getquote_button() throws Throwable {
    	takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form[2]/button")).click();
        
    }

    @And("^User fills in location table clicks continue$")
    public void user_fills_in_location_table_clicks_continue() throws Throwable {
     d.findElement(By.xpath("/html/body/form/div[1]/select")).click();
     d.findElement(By.xpath("/html/body/form/div[1]/select/option[3]")).click();
     d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("100 Main St");
     d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("Apt 1");
     d.findElement(By.xpath("/html/body/form/div[4]/input")).sendKeys("Dallas");
     d.findElement(By.xpath("/html/body/form/div[5]/input")).sendKeys("TX");
     d.findElement(By.xpath("/html/body/form/div[6]/input")).sendKeys("75201");
     d.findElement(By.xpath("/html/body/form/div[7]/select")).click();
     d.findElement(By.xpath("/html/body/form/div[7]/select/option[2]")).click();
     takeScreenShot(d);
     d.findElement(By.xpath("/html/body/form/div[8]/input")).click();
    
    }

    @And("^User fills in homeowner table clicks continue$")
    public void user_fills_in_homeowner_table_clicks_continue() throws Throwable {
       d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
       d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("Fox");
       d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("07311955");
       d.findElement(By.xpath("/html/body/form/div[4]/input[1]")).click();
       d.findElement(By.xpath("/html/body/form/div[5]/input")).sendKeys("123456789");
       d.findElement(By.xpath("/html/body/form/div[6]/input")).sendKeys("mike@email.com");
       takeScreenShot(d);
       d.findElement(By.xpath("/html/body/form/div[7]/input")).click();
      
    }

    @And("^User fills in property table clicks continue$")
    public void user_fills_in_property_table_clicks_continue() throws Throwable {
        d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("12000");
        d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("1999");
        d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("1500");
        d.findElement(By.xpath("/html/body/form/div[9]/input[1]")).click();
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form/div[10]/input")).click();
       
        
    }
	
}
