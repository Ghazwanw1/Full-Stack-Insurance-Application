package com.cts.HomeInsurance.Automation;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;



@RunWith(Suite.class)
@SuiteClasses({ RegisterTestRunner.class, LoginTestRunner.class,  GetQuoteTestRunner.class, RetrieveQuoteTestRunner.class, RetrieveBuyTestRunner.class, GetBuyTestRunner.class, AdminViewTestRunner.class, AdminRenewTestRunner.class, AdminCancelTestRunner.class })
public class AllTests {

}
