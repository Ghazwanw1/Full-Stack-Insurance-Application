package com.cts.HomeInsurance.manualTesing;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.HomeInsurance.BO.LocationBO;
import com.cts.HomeInsurance.BO.PolicyBO;
import com.cts.HomeInsurance.BO.QuoteBo;
import com.cts.HomeInsurance.DAO.OracleConnection;
import com.cts.HomeInsurance.DAO.PolicyDAO;
import com.cts.HomeInsurance.DAO.QuoteDAO;
import com.cts.HomeInsurance.DAO.UserDAO;
import com.cts.HomeInsurance.model.Location;
import com.cts.HomeInsurance.model.Policy;
import com.cts.HomeInsurance.model.Quote;
import com.cts.HomeInsurance.model.User;

public class Testing {

	public static void main(String[] args) 
			throws SQLException, ClassNotFoundException, IOException {
		
//			UserDAO f=new UserDAO();
//			User d=f.getUserByUser_Name("SysAdmin");
//			String ss=d.getPassword();
//			System.out.println(ss);

//		UserDAO s = new UserDAO();
//		List<User> ul = new ArrayList<User>();
//		ul = s.getAllUsers();
//		for (User d : ul) {
//			System.out.println(d.getUserName());}		
		
//		User u= new User();
//		u.setUserName("bb");
//		u.setPassword("bb");
//		UserDAO udao=new UserDAO();
//		int i = udao.registerUser(u);
//		System.out.println(i);
//		
//			System.out.println(u.getUserName());}
		
//		PolicyDAO pdao=new PolicyDAO();
//		Policy p=pdao.getPolicyByUser_Name("aaa");
//		System.out.println(p.getPolicyId());
//		PolicyDAO pdao=new PolicyDAO();
//		List<Policy> pl=pdao.getAllPolicies("ggg");
//		for(Policy p:pl) {
//			System.out.println(p.getPolicyId());
//		}
//		
//	PolicyBO pbo=new PolicyBO();
//	Policy p=pbo.getPolicyById(22);
//	pbo.renewPolicy(p);
//	//pbo.cancelPolicy(p);
//		
//
//		List<Quote> ql;
//		QuoteDAO qdao=new QuoteDAO();
//		ql=qdao.getAllQuotes(82);
//		for(Quote q:ql) {
//			System.out.println(q.getMonthlyPremium());
//		}
		
//		QuoteBo qbo=new QuoteBo();
//		Quote q=qbo.getQuoteById(321);
//		System.out.println(q.getMonthlyPremium());
		
		LocationBO lbo=new LocationBO();
		Location l=lbo.getLocationQuote_Id(321);
		System.out.println(l.getAddressLine1());
		
	}
	
	
	public Boolean removeUser(int userId) throws IOException, SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		Integer updateResult = null;
		
		// Assign delete string to variable
		String deleteString = "delete from users where user_id = ?";
		
		// Create MySqlConnection class instance
		OracleConnection orcl = new OracleConnection();
		// Begin try/catch block to query the database
		try
		{
			// Connect to database and assign query string to PreparedStatement object
			conn = orcl.getConnection();
			stmt = conn.prepareStatement(deleteString);
			
			// Set query parameters (?)
			stmt.setInt(1, userId);
			// Run query and assign to ResultSet
			updateResult = stmt.executeUpdate();
		}
		catch (ClassNotFoundException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		finally
		{
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		if (updateResult > 0) {
			return true;
		}
		return false;
	} // End of removeUser() method

}