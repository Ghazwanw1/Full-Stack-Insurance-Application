package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.cts.HomeInsurance.DAO.LocationDAO;
import com.cts.HomeInsurance.model.Location;

public class LocationDAOTest {

	@Test
	public void testGetAllLocation() throws SQLException{
		LocationDAO loc= new LocationDAO();
		List<Location> ll=loc.getAllLocations();
		assertNotNull(ll);
	}

//	@Test
//	public void testGetLocationByUser_Id() throws SQLException, ClassNotFoundException, IOException{
//		LocationDAO loc= new LocationDAO();
//		Location l=new Location();
//		l=loc.getLocationByUser_Id(1);
//		assertNotNull(l);		
//	}
//
//	@Test
//	public void testRegisterHomeowner() throws ClassNotFoundException, SQLException, IOException {
//
//		Location loc=new Location();
//
//		loc.setLocationId(1);
//		loc.setUserId(1);
//		loc.setResidenceType("Commercial");
//		loc.setAddressLine1("100 Main St");
//		loc.setAddressLine2(" ");
//		loc.setCity("Dallas");
//		loc.setLocationState("TX");
//		loc.setZipCode("75201");
//		loc.setResidenceUse("Office");
//
//
//
//
//
//		LocationDAO hoi=new LocationDAO(); 
//		int colnum=0;
//		colnum=hoi.registerLocation(loc);
//		assertEquals("Dallas", loc.getCity());
//		assertNotEquals(colnum, 0);
//
//	}
}
