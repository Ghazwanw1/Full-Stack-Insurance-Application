package com.cts.HomeInsurance.step_definitions;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
public class AdminRenew {
	private static WebDriver d;

	private void takeScreenShot(WebDriver driver) throws IOException {
	    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
	}
	@Given("^User has Admin priviliges navigates to homeinsurance website$")
    public void user_has_admin_priviliges_navigates_to_homeinsurance_website() throws Throwable {
		System.setProperty("webdriver.chrome.driver", 
				"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		d = new ChromeDriver();
		d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		d.manage().window().maximize();
		takeScreenShot(d);
    }

    @Then("^Admin gets directed to a page where it shows that policy has been renewed confirms it and logout$")
    public void admin_gets_directed_to_a_page_where_it_shows_that_policy_has_been_renewed_confirms_it_and_logout() throws Throwable {
        assertTrue(d.findElement(By.xpath("/html/body/table/tbody/tr[6]/td")).getText().contentEquals("RENEWED"));
        assertThat(d.findElement(By.xpath("/html/body/table/tbody/tr[5]/td")).getText(), equalTo("2"));
        d.findElement(By.xpath("/html/body/a[2]")).click();
        takeScreenShot(d);
        d.close();
    }

    @And("^User click on Admin Login link and get directed to the spring contoller$")
    public void user_click_on_admin_login_link_and_get_directed_to_the_spring_contoller() throws Throwable {
    	d.findElement(By.xpath("/html/body/a[2]")).click();
        assertTrue(d.getCurrentUrl().contains("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/admin/adminLogin"));
        takeScreenShot(d);
    }

    @And("^Admin use admin username and password to login$")
    public void admin_use_admin_username_and_password_to_login() throws Throwable {
    	d.findElement(By.xpath("/html/body/form/input[1]")).sendKeys("WebAdmin");
        d.findElement(By.xpath("/html/body/form/input[2]")).sendKeys("AdminPassword");
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form/input[3]")).click();
    }

    @And("^Admin fill in username and clicks on search$")
    public void admin_fill_in_username_and_clicks_on_search() throws Throwable {
    	d.findElement(By.xpath("/html/body/form/input[1]")).sendKeys("Mike");
    	takeScreenShot(d);
    	d.findElement(By.xpath("/html/body/form/input[2]")).click();
    }

    @And("^Admin get directed to a page where it show a list of policies for that username$")
    public void admin_get_directed_to_a_page_where_it_show_a_list_of_policies_for_that_username() throws Throwable {
    	
    	assertTrue(d.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[6]")).getText().contentEquals("Active"));
        assertTrue(d.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[6]")).getText().contentEquals("Active"));
        takeScreenShot(d);
    }

    @And("^Admin clicks on renew on one of the policies from the policies table$")
    public void admin_clicks_on_renew_on_one_of_the_policies_from_the_policies_table() throws Throwable {
        d.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[7]/a")).click();
        takeScreenShot(d);
    }
}
