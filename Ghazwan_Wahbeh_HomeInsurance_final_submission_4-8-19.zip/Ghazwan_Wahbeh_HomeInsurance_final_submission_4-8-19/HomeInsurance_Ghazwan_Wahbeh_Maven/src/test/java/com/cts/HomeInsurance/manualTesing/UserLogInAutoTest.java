package com.cts.HomeInsurance.manualTesing;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assume.assumeTrue;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import com.cts.HomeInsurance.DAO.OracleConnection;


public class UserLogInAutoTest {
	private static WebDriver driver;
	private static OracleConnection orcl;
	private static Connection conn;
	private static Boolean databaseIsOnline;
	private static String screenshotFolder;

	@BeforeClass
	public static void setUp() {
		System.setProperty("webdriver.chrome.driver", 
				"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();

		try {
			orcl = new OracleConnection();
			conn = orcl.getConnection();
			databaseIsOnline = true;
			conn.close();
		}
		catch (Exception e)
		{
			databaseIsOnline = false;
			System.out.println("UserDAOTest Class: Could not connect to the database. "
					+ "Tests will be skipped");
		}

		screenshotFolder = "Screenshots_" + LocalDateTime.now();
	}
	@AfterClass
	public static void tearDownClass() {
		driver.close();
	}
	
	@Test
	public void loginTest() throws IOException {
		assumeTrue(databaseIsOnline);
		
		driver.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		assertThat(driver.getTitle(), equalTo("User Log In Page"));
		WebElement loginInput = driver.findElement(By.xpath("/html/body/form/div[1]/input"));
		loginInput.sendKeys("ggg");
		WebElement passwordInput = driver.findElement(By.xpath("/html/body/form/div[2]/input"));
		passwordInput.sendKeys("ggg");
    	takeScreenShot(driver);
    	
		driver.findElement(By.cssSelector("body > form > div:nth-child(3) > input[type=\"submit\"]")).click();
		assertThat(driver.findElement(By.cssSelector("body > h1")).getText(), containsString("ggg"));
		assertThat(driver.getTitle(), equalTo("Welcome Page"));
		takeScreenShot(driver);
		
		driver.findElement(By.cssSelector("body > header > a")).click();
		takeScreenShot(driver);
	}
	

    private void takeScreenShot(WebDriver driver) throws IOException {
        File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
   }
}
