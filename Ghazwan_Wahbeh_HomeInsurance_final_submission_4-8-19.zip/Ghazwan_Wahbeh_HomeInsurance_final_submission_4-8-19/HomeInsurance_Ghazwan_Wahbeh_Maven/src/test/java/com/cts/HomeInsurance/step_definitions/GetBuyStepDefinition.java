package com.cts.HomeInsurance.step_definitions;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
public class GetBuyStepDefinition {
	private static WebDriver d;

	private void takeScreenShot(WebDriver driver) throws IOException {
	    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
	}
	
	
	@Given("^Registred user navigates to homeinsurance website$")
    public void registred_user_navigates_to_homeinsurance_website() throws Throwable {
		System.setProperty("webdriver.chrome.driver", 
				"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		d = new ChromeDriver();
		d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		d.manage().window().maximize();
		takeScreenShot(d);
    }

    @Then("^User gets to Policy Confirmations page and clicks logout$")
    public void user_gets_to_policy_confirmations_page_and_clicks_logout() throws Throwable {
        assertThat(d.findElement(By.cssSelector("body > section > article:nth-child(2) > table > tbody > tr:nth-child(6) > td:nth-child(2)")).getText(), equalTo("Active"));
        assertTrue(d.getCurrentUrl().contentEquals("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/policyConf"));
        takeScreenShot(d);
        d.findElement(By.cssSelector("body > header > a:nth-child(5)")).click();
        takeScreenShot(d);
        d.close();
    }

    @And("^User signsin with his username and password$")
    public void user_signsin_with_his_username_and_password() throws Throwable {
   	 d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
     d.findElement(By.name("pass")).sendKeys("MikePassword");
     takeScreenShot(d);
     d.findElement(By.xpath("/html/body/form/div[3]/input")).click();
  
    }

    @And("^User click getquote button$")
    public void user_click_getquote_button() throws Throwable {
    	takeScreenShot(d);
    	d.findElement(By.xpath("/html/body/form[2]/button")).click();
    	takeScreenShot(d);
    }

    @And("^User fill in location table clicks continue$")
    public void user_fill_in_location_table_clicks_continue() throws Throwable {
    	   d.findElement(By.xpath("/html/body/form/div[1]/select")).click();
    	     d.findElement(By.xpath("/html/body/form/div[1]/select/option[3]")).click();
    	     d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("200 Commerce St");
    	     d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("Apt 2");
    	     d.findElement(By.xpath("/html/body/form/div[4]/input")).sendKeys("Tulsa");
    	     d.findElement(By.xpath("/html/body/form/div[5]/input")).sendKeys("OK");
    	     d.findElement(By.xpath("/html/body/form/div[6]/input")).sendKeys("74001");
    	     d.findElement(By.xpath("/html/body/form/div[7]/select")).click();
    	     d.findElement(By.xpath("/html/body/form/div[7]/select/option[2]")).click();
    	     takeScreenShot(d);
    	     d.findElement(By.xpath("/html/body/form/div[8]/input")).click();
    	     
    }

  @And("^User fill in homeowner table clicks continue$")
  public void user_fill_in_homeowner_table_clicks_continue() throws Throwable {
	  d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
      d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("Fox");
      d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("07311955");
      d.findElement(By.xpath("/html/body/form/div[4]/input[1]")).click();
      d.findElement(By.xpath("/html/body/form/div[5]/input")).sendKeys("123456789");
      d.findElement(By.xpath("/html/body/form/div[6]/input")).sendKeys("mike@email.com");
      d.findElement(By.xpath("/html/body/form/div[7]/input")).click();
  }

    @And("^User fill in property table clicks continue$")
    public void user_fill_in_property_table_clicks_continue() throws Throwable 

    { d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("9000");
    	        d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("1966");
    	        d.findElement(By.xpath("/html/body/form/div[3]/input")).sendKeys("1200");
    	        d.findElement(By.xpath("/html/body/form/div[9]/input[1]")).click();
    	        takeScreenShot(d);
    	        d.findElement(By.xpath("/html/body/form/div[10]/input")).click();
    	        takeScreenShot(d);
    }

    @And("^User get to coverage details and views his quote and clicks Proceed to buy$")
    public void user_get_to_coverage_details_and_views_his_quote_and_clicks_proceed_to_buy() throws Throwable {
    	 assertThat(d.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]")).getText(), equalTo("4.0125"));
    	 takeScreenShot(d);
    	 d.findElement(By.xpath("/html/body/a[2]/input")).click();
    	 takeScreenShot(d);
    }

    @And("^User gets to quote summary to view all the table he filled in and click Buy quote$")
    public void user_gets_to_quote_summary_to_view_all_the_table_he_filled_in_and_click_buy_quote() throws Throwable {
        assertThat(d.findElement(By.xpath("/html/body/div[2]/section[2]/article[2]/table/tbody/tr[1]/td[2]")).getText(), equalTo("4.0125"));
        assertTrue(d.getTitle().contentEquals("Quote Summary"));
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form[1]/section/input")).click();
        takeScreenShot(d);
    }

    @And("^User fills in Policy start date and acknowledge the terms and clicks Submit$")
    public void user_fills_in_policy_start_date_and_acknowledge_the_terms_and_clicks_submit() throws Throwable {
        assertTrue(d.getCurrentUrl().equalsIgnoreCase("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/buyQuote"));
        d.findElement(By.cssSelector("body > div > div:nth-child(2) > form > input[type=\"date\"]:nth-child(2)")).sendKeys("05312019");
        d.findElement(By.cssSelector("#chkBox")).click();
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/div/div[2]/form/input[3]")).click();
        
    }
}
