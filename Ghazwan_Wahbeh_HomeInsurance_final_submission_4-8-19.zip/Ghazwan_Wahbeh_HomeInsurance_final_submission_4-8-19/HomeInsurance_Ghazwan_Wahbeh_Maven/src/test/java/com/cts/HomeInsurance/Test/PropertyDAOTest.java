package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.cts.HomeInsurance.DAO.PropertyDAO;
import com.cts.HomeInsurance.model.Property;

public class PropertyDAOTest {

	@Test
	public void testGetAllProperty() throws SQLException{
		PropertyDAO pro= new PropertyDAO();
		List<Property> pr=pro.getAllProperties();
		assertNotNull(pr);
	}

	@Test
	public void testGetLocationByUser_Id() throws SQLException, ClassNotFoundException, IOException{
		PropertyDAO pro= new PropertyDAO();
		Property p=new Property();
		p=pro.getPropertyByLocation_Id(1);
		assertNotNull(p);		
	}

	@Test
	public void testRegisterHomeowner() throws ClassNotFoundException, SQLException, IOException {

		Property pro=new Property();

		pro.setLocationId(3);
		pro.setMarketValue(543.3233f);
		pro.setYearBuilt("2000");
		pro.setSquareFootage(3512);
		pro.setDwellingType("Residential");
		pro.setRoofMaterial("Bricks");
		pro.setGarageType("Seperate");
		pro.setFullBaths(4);
		pro.setHalfBaths(2);
		pro.setPool(false);





		PropertyDAO hoi=new PropertyDAO(); 
		int colnum=0;
		colnum=hoi.registerProperty(pro);
		assertEquals(4, pro.getFullBaths());
		assertNotEquals(colnum, 0);

	}
	
}
