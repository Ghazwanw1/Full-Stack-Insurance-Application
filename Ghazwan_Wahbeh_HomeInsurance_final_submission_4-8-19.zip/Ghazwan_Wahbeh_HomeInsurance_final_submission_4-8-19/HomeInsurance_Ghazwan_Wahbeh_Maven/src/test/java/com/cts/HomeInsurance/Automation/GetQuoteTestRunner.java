package com.cts.HomeInsurance.Automation;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/java/com/cts/HomeInsurance/features/GetQuote.feature",
	glue= {"com/cts/HomeInsurance/step_definitions"}
			)

public class GetQuoteTestRunner {

}
