package com.cts.HomeInsurance.step_definitions;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class RetrieveQuoteStepDefinition {

	private static WebDriver d;

	private void takeScreenShot(WebDriver driver) throws IOException {
	    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
	}
	
	
	@Given("^Registred User navigate to homeinsurance website$")
    public void registred_user_navigate_to_homeinsurance_website() throws Throwable {
		System.setProperty("webdriver.chrome.driver", 
				"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		d = new ChromeDriver();
		d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		d.manage().window().maximize();
		takeScreenShot(d);
    }

    @Then("^User views coverage details and logout$")
    public void user_views_coverage_details_and_logout() throws Throwable {
    	 assertThat(d.findElement(By.xpath("/html/body/div[2]/section[2]/article[2]/table/tbody/tr[1]/td[2]")).getText(), equalTo("5.35"));
    	 takeScreenShot(d);
    	 d.findElement(By.xpath("/html/body/header/a[5]")).click();
        
         d.close();
    }

    @And("^User logsin with his username and password$")
    public void user_logsin_with_his_username_and_password() throws Throwable {
        d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
        d.findElement(By.name("pass")).sendKeys("MikePassword");
        takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form/div[3]/input")).click();
        
    }

    @And("^User clicks retrievequote button$")
    public void user_clicks_retrievequote_button() throws Throwable {
    	takeScreenShot(d);
        d.findElement(By.xpath("/html/body/form[1]/button")).click();
        
    }

    @And("^User views info about specific quote by clicking on view$")
    public void user_views_info_about_specific_quote_by_clicking_on_view() throws Throwable {
    	takeScreenShot(d);
        d.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[10]/a")).click();
        
    }	
}
