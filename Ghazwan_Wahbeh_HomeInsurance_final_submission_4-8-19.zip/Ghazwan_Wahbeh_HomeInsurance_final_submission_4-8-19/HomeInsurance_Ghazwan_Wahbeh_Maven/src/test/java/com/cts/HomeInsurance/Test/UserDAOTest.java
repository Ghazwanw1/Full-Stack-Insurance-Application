package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.cts.HomeInsurance.DAO.UserDAO;
import com.cts.HomeInsurance.model.User;

public class UserDAOTest {

	@Test
	public void testGetAllUser() throws SQLException{
		UserDAO usr= new UserDAO();
		List<User> ll=usr.getAllUsers();
		assertNotNull(ll);
	}

	@Test
	public void testGetUserByUser_Name() throws SQLException, ClassNotFoundException, IOException{
		UserDAO usr= new UserDAO();
		User u=new User();
		u=usr.getUserByUser_Name("ggg");
		assertNotNull(u);		
	}

	@Test
	public void testRegisterUser() throws ClassNotFoundException, SQLException, IOException {

		User usr=new User();

		
		usr.setUserId(6);
		usr.setUserName("Jamesusername");
		usr.setPassword("StrongPassword");
		usr.setAdminRole("Admin");
		


		UserDAO hoi=new UserDAO(); 
		int colnum=0;
		colnum=hoi.registerUser(usr);
		assertEquals("StrongPassword", usr.getPassword());
		assertNotEquals(colnum, 0);

	}
	
}
