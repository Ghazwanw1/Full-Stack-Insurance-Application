package com.cts.HomeInsurance.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.apache.commons.io.FileUtils;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginStepDefinition {

	private static WebDriver d;

	private void takeScreenShot(WebDriver driver) throws IOException {
	    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
	}
	
	 @Given("^Registered user navigates to homeinsurance website$")
	    public void registered_user_navigates_to_homeinsurance_website() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", 
	 "C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
		d = new ChromeDriver();
		  
		d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
		takeScreenShot(d);
	    }

	    @Then("^User logout$")
	    public void user_logout() throws Throwable {
	        	d.findElement(By.xpath("/html/body/header/a[5]")).click();
	    
	        	takeScreenShot(d);
	        	d.close();
	    }

	    @And("^User enters his username$")
	    public void user_enters_his_username() throws Throwable {
	        d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
	     
	        takeScreenShot(d);
	    }

	    @And("^User enters his password$")
	    public void user_enters_his_password() throws Throwable {
	        d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("MikePassword");
	     
	        takeScreenShot(d);
	    }

	    @And("^User clicks login button$")
	    public void user_clicks_login_button() throws Throwable {
	        d.findElement(By.xpath("/html/body/form/div[3]/input")).click();
	     
	        takeScreenShot(d);
	    }

	   
	    
	    @And("^User gets on welcome page with his name$")
	    public void user_gets_on_welcome_page_with_his_name() throws Throwable {
	    
	      WebElement we=d.findElement(By.xpath("/html/body/h1"));
	      String t=we.getText();
	        assertThat(t, equalTo("Welcome Mike!"));
	        takeScreenShot(d);
	    }

	
	
}
