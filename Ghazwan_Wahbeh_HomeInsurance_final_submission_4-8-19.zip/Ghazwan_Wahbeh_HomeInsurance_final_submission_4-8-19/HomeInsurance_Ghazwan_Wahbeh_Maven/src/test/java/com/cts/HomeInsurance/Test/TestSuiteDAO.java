package com.cts.HomeInsurance.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Suite.class)
@SuiteClasses({HomeownerDAOTest.class, LocationDAOTest.class, PolicyDAOTest.class, QuoteDAOTest.class, UserDAOTest.class, PropertyDAOTest.class} )
public class TestSuiteDAO {

}
