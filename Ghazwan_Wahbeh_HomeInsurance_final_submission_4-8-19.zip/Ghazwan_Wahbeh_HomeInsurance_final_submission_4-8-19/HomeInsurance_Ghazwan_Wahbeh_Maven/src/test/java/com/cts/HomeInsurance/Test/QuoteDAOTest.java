package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.cts.HomeInsurance.DAO.QuoteDAO;
import com.cts.HomeInsurance.model.Quote;

public class QuoteDAOTest {

	
	@Test
	public void testGetAllLocation(int userId) throws SQLException{
		QuoteDAO qt= new QuoteDAO();
		List<Quote> qq=qt.getAllQuotes(userId);
		assertNotNull(qq);
		
	}

	@Test
	public void testGetQuoteByLocation_Id() throws SQLException, ClassNotFoundException, IOException{
		QuoteDAO qt= new QuoteDAO();
		Quote q=new Quote();
		q=qt.getQuoteByLocation_Id(1);
		assertNotNull(q);		
	}

	@Test
	public void testRegisterQuote() throws ClassNotFoundException, SQLException, IOException {

		Quote qt=new Quote();

		qt.setQuoteId(5);
		qt.setLocationId(1);
		qt.setMonthlyPremium(233.99f);
		qt.setDwellingCoverage(323.54f);
		qt.setDetatchedStructures(676.78f);
		qt.setPersonalProperty(989.3442f);
		qt.setAddLivingExp(7834.78f);
		qt.setMedicalExpenses(7.43f);
		qt.setDeductible(43.34f);





		QuoteDAO hoi=new QuoteDAO(); 
		int colnum=0;
		colnum=hoi.registerQuote(qt);
		assertEquals(1, qt.getLocationId());
		assertNotEquals(colnum, 0);

	}
	
}
