package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import org.junit.Test;

import com.cts.HomeInsurance.DAO.PolicyDAO;
import com.cts.HomeInsurance.model.Policy;

public class PolicyDAOTest {

	@Test
	public void testGetAllPolicy(String User_Name) throws SQLException{
		PolicyDAO pol= new PolicyDAO();
		List<Policy> p=pol.getAllPolicies(User_Name);
		assertNotNull(p);
	}

	@Test
	public void testGetLocationByUser_Name() throws SQLException, ClassNotFoundException, IOException{
		PolicyDAO pol= new PolicyDAO();
		Policy p=new Policy();
		p=pol.getPolicyByUser_Name("JamesUserName");
		assertNotNull(p);		
	}

	@Test
	public void testRegisterHomeowner() throws ClassNotFoundException, SQLException, IOException {

		Policy pol=new Policy();

		pol.setPolicyId(6);
		pol.setQuoteId(6);
		pol.setUserId(2);
		pol.setEffectiveDate(new Date(2020/1/1));
		pol.setEndDate(new Date(2021/1/1));
		pol.setTerm(1);
		pol.setPolicyStatus("Active");

		PolicyDAO hoi=new PolicyDAO(); 
		int colnum=0;
		colnum=hoi.registerPolicy(pol);
		assertEquals("Active", pol.getPolicyStatus());
		assertNotEquals(colnum, 0);

	}
	
	
}
