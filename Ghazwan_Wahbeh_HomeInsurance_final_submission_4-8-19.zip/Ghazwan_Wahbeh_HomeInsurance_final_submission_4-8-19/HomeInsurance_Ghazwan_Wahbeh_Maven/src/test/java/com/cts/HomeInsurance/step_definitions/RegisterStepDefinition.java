package com.cts.HomeInsurance.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;
import cucumber.api.junit.Cucumber;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.io.FileUtils;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RegisterStepDefinition {
	
private static WebDriver d;

private void takeScreenShot(WebDriver driver) throws IOException {
    File scrFile  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    FileUtils.copyFile(scrFile, new File(".\\Screenshots\\" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy.MM.dd_HH.mm.ss.SSS")) + ".png"));
}

	 @Given("^User is on the login page$")
	    public void user_is_on_the_login_page() throws Throwable {
		 
		 System.setProperty("webdriver.chrome.driver", 
					"C:/Users/G/eclipse-workspace/My_JARs/chromedriver_win32/chromedriver.exe");
			d = new ChromeDriver();
			d.get("http://localhost:8080/HomeInsurance_Ghazwan_Wahbeh_Maven/");
			d.manage().window().maximize();
			takeScreenShot(d);
	    }

	    @When("^User clicks on register button$")
	    public void user_clicks_on_register_button() throws Throwable {
	        d.findElement(By.xpath("/html/body/a[1]")).click();
	        takeScreenShot(d);
	    }

	    @Then("^User is directed to login page$")
	    public void user_is_directed_to_login_page() throws Throwable {
	    	assertThat(d.getTitle(), equalTo("User Log In Page")); 
	    	takeScreenShot(d);
	    	d.close();
	    }

	    @And("^User enters his new username and password$")
	    public void user_enters_his_new_username_and_password() throws Throwable {
	        d.findElement(By.xpath("/html/body/form/div[1]/input")).sendKeys("Mike");
	        d.findElement(By.xpath("/html/body/form/div[2]/input")).sendKeys("MikePassword");
	        takeScreenShot(d);
	    }

	    @And("^User clicks signup$")
	    public void user_clicks_signup() throws Throwable {
	       d.findElement(By.xpath("/html/body/form/div[3]/input")).click();
	       takeScreenShot(d);
	    }

}
