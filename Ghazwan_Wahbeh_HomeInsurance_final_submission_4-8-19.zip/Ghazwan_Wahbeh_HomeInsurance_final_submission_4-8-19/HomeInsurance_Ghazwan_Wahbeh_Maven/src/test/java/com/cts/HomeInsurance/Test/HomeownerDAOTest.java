package com.cts.HomeInsurance.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;


import org.junit.Test;

import com.cts.HomeInsurance.DAO.HomeownerDAO;
import com.cts.HomeInsurance.model.Homeowner;

public class HomeownerDAOTest {
	   
    	
    @Test
	public void testGetAllHomeowner() throws SQLException{
    	  HomeownerDAO hd= new HomeownerDAO();
		List<Homeowner> hoa=hd.getAllHomeowners();
		assertNotNull(hoa);
	}

	@Test
	public void testGetHomeownerByUser_Id() throws SQLException, ClassNotFoundException, IOException{
		  HomeownerDAO hd= new HomeownerDAO();
		Homeowner h=new Homeowner();
		h=hd.getHomeownerByUser_Id(2);
		assertNotNull(h);		
	}
	
	@Test
	public void testRegisterHomeowner() throws ClassNotFoundException, SQLException, IOException {
		 		
		Homeowner jj=new Homeowner();
		jj.setUserId(2); 
		jj.setFirstName("Eric");
		jj.setLastName("White");
		jj.setDob(new Date(2005-1900, 3, 20)); 
		jj.setRetiredStatus(false);
		jj.setSsn("1234567"); 
		jj.setEmail("ericwhite@email.com"); 
		
		
		
		HomeownerDAO hoi=new HomeownerDAO(); 
		int colnum=0;
		colnum=hoi.registerHomeowner(jj);
		assertEquals("Eric", jj.getFirstName());
		assertNotEquals(colnum, 0);
	}

}
